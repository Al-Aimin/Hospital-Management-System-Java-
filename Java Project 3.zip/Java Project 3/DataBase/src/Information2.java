
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
public class Information2 extends javax.swing.JFrame {
    Connection conn = null;
    ResultSet res = null;
    PreparedStatement pre = null;
    String s = new String();
  
    public Information2() {
        initComponents();
        conn = Window.ConnectDB();
        Table();
        setTitle("Doctor Information");
    }
    private void Table() {
    try{
        String s ="select * from Test3";
        pre=conn.prepareStatement(s);
        res=pre.executeQuery();
        doc_info.setModel(DbUtils.resultSetToTableModel(res));
    }
    catch(Exception e){
    JOptionPane.showMessageDialog(null, e);
    }
    finally {
            
            try{
                res.close();
                pre.close();
                
            }
            catch(Exception e){
                
            }
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        Employe_name = new javax.swing.JLabel();
        Id = new javax.swing.JLabel();
        Degree = new javax.swing.JLabel();
        Post = new javax.swing.JLabel();
        Mail = new javax.swing.JLabel();
        Phone = new javax.swing.JLabel();
        txt2 = new javax.swing.JTextField();
        txt1 = new javax.swing.JTextField();
        txt3 = new javax.swing.JTextField();
        txt4 = new javax.swing.JTextField();
        txt5 = new javax.swing.JTextField();
        txt6 = new javax.swing.JTextField();
        txt7 = new javax.swing.JTextField();
        Age = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        serchid = new javax.swing.JLabel();
        search = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        doc_info = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        add = new javax.swing.JButton();
        add1 = new javax.swing.JButton();
        add2 = new javax.swing.JButton();
        add3 = new javax.swing.JButton();
        Age1 = new javax.swing.JLabel();
        male = new javax.swing.JRadioButton();
        female = new javax.swing.JRadioButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(220, 31, 106));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Doctor Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 36))); // NOI18N

        Employe_name.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Employe_name.setText("Doctor Name:");

        Id.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Id.setText("Doctor Id:");

        Degree.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Degree.setText("Qualification:");

        Post.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Post.setText("Experties:");

        Mail.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Mail.setText("Email:");

        Phone.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Phone.setText("Telephone:");

        txt2.setBackground(new java.awt.Color(255, 204, 255));
        txt2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        txt1.setBackground(new java.awt.Color(204, 255, 204));
        txt1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        txt3.setBackground(new java.awt.Color(255, 204, 204));
        txt3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt3ActionPerformed(evt);
            }
        });

        txt4.setBackground(new java.awt.Color(204, 255, 255));
        txt4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt4ActionPerformed(evt);
            }
        });

        txt5.setBackground(new java.awt.Color(255, 204, 153));
        txt5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt5ActionPerformed(evt);
            }
        });

        txt6.setBackground(new java.awt.Color(126, 248, 224));
        txt6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt6ActionPerformed(evt);
            }
        });

        txt7.setBackground(new java.awt.Color(255, 255, 204));
        txt7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt7ActionPerformed(evt);
            }
        });

        Age.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Age.setText("Age:");

        jPanel1.setBackground(new java.awt.Color(153, 88, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        serchid.setBackground(new java.awt.Color(102, 255, 255));
        serchid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        serchid.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        serchid.setText("Id:");

        search.setBackground(new java.awt.Color(204, 255, 255));
        search.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        search.setForeground(new java.awt.Color(55, 200, 55));
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        doc_info.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        doc_info.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                doc_infoAncestorMoved(evt);
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        doc_info.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doc_infoMouseClicked(evt);
            }
        });
        doc_info.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                doc_infoKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(doc_info);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(serchid, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 467, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 84, Short.MAX_VALUE))
            .addComponent(jScrollPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(serchid, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
        );

        jPanel3.setBackground(new java.awt.Color(255, 102, 153));

        add.setBackground(new java.awt.Color(0, 153, 0));
        add.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Save-icon.png"))); // NOI18N
        add.setText("Add Record");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        add1.setBackground(new java.awt.Color(102, 204, 0));
        add1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        add1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/delete_16x16.gif"))); // NOI18N
        add1.setText("Delete");
        add1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add1ActionPerformed(evt);
            }
        });

        add2.setBackground(new java.awt.Color(0, 153, 153));
        add2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        add2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/update icon.png"))); // NOI18N
        add2.setText("Update");
        add2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add2ActionPerformed(evt);
            }
        });

        add3.setBackground(new java.awt.Color(0, 153, 153));
        add3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        add3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/erase-128.png"))); // NOI18N
        add3.setText("Clear");
        add3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(add3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(add2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(add1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(add2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(add3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(add1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        Age1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Age1.setText("Gender:");

        male.setText("Male");
        male.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleActionPerformed(evt);
            }
        });

        female.setText("Female");
        female.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                femaleActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Id)
                    .addComponent(Employe_name)
                    .addComponent(Degree)
                    .addComponent(Post)
                    .addComponent(Mail)
                    .addComponent(Age)
                    .addComponent(Phone)
                    .addComponent(Age1))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txt1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
                        .addComponent(txt2, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt3, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt4, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt5, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt7, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt6, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(male)
                        .addGap(58, 58, 58)
                        .addComponent(female)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 251, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Id))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Employe_name))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Degree))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Age1)
                            .addComponent(male)
                            .addComponent(female))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Post))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Mail))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt6, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Phone))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt7, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Age))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/file.png"))); // NOI18N
        jMenu1.setText("File");

        jMenuItem3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back-icon.png"))); // NOI18N
        jMenuItem3.setText("Back");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logout.png"))); // NOI18N
        jMenuItem2.setText("Logout");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/delete_16x16.gif"))); // NOI18N
        jMenuItem4.setText("Exit");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 578, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed

    }//GEN-LAST:event_searchActionPerformed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
        try{

            String s= "select * from Test3 where id=? ";

            pre=conn.prepareStatement(s);
            pre.setString(1,search.getText());
            res=pre.executeQuery();

            String add1 = res.getString("id");
            txt1.setText(add1);
            
            String add2 =res.getString("name");
            txt2.setText(add2);

            String add3 =res.getString("degree");
            txt3.setText(add3);
            
            String add7 =res.getString("experties");
            txt4.setText(add7);
            
            String add4 =res.getString("mail");
            txt5.setText(add4);

            String add5 =res.getString("phone");
            txt6.setText(add5);

            String add6 =res.getString("age");
            txt7.setText(add6);



            /*   byte[] img = res.getBytes("Image");
            ImageIcon imageIcon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH));
            lbl_img.setIcon(imageIcon);*/

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally {

            try{

                res.close();
                pre.close();

            }
            catch(Exception e){

            }
        }
    }//GEN-LAST:event_searchKeyReleased

    private void txt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt3ActionPerformed

    private void txt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt4ActionPerformed

    private void txt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt5ActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        int p = JOptionPane.showConfirmDialog(null, "Are you sure you want to add record?","Add Record",JOptionPane.YES_NO_OPTION);
        
        if(p==0)
        {
        if((txt1.getText().isEmpty()) && (txt2.getText().isEmpty()) && (txt3.getText().isEmpty()) &&(txt4.getText().isEmpty())&& (txt5.getText().isEmpty()) && (txt6.getText().isEmpty()) && (txt7.getText().isEmpty()))
        {
        JOptionPane.showMessageDialog(null,"Fill up all the boxes");
        }
            else{
                ResultSet res=null;
                PreparedStatement pre=null;
                String s=new String();

                String id = txt1.getText();
                String name = txt2.getText();
                String degree = txt3.getText();
                String experties = txt4.getText();
                String mail = txt5.getText();
                String phone = txt6.getText();
                String age = txt7.getText();
                
                try{

                s="Insert into Test3 values('"+id+"','"+name+"','"+degree+"','"+experties+"','"+mail+"','"+phone+"','"+age+"','"+gender+"')";
                pre=conn.prepareStatement(s);
                
                pre.setString(1,txt1.getText());
                pre.setString(2,txt2.getText());
                pre.setString(3,txt3.getText());
                pre.setString(4,txt4.getText());
                pre.setString(5,txt5.getText());
                pre.setString(6,txt6.getText());
                pre.setString(7,txt7.getText());
                pre.setString(8,gender);
                
                pre.execute();
                JOptionPane.showMessageDialog(null,"Data is saved successfully");

                }
                catch(Exception e){
                System.out.println(e);
                }
            }
            

                try{

                res.close();
                pre.close();

                }
                catch(Exception e){

                }   
        }
        Table();
    }//GEN-LAST:event_addActionPerformed

    private void add1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add1ActionPerformed
        int p = JOptionPane.showConfirmDialog(null, "Are you sure you want to Delete record?","Delete Record",JOptionPane.YES_NO_OPTION);
        if(p==0){
            String sql ="delete from Test3 where id=? ";
            try{
                pre=conn.prepareStatement(sql);
                pre.setString(1, search.getText());
                pre.execute();

                JOptionPane.showMessageDialog(null,"Record Deleted");

            }catch(Exception e){

                JOptionPane.showMessageDialog(null, e);
            }
            
             finally {

                try{

                    res.close();
                    pre.close();

                }
                catch(Exception e){

                }
            }
        }
        Table();
    }//GEN-LAST:event_add1ActionPerformed

    private void add2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add2ActionPerformed
        int p = JOptionPane.showConfirmDialog(null, "Are you sure you want to update?","Update Record",JOptionPane.YES_NO_OPTION);
        if(p==0){
            try{
                String value1 = txt1.getText();
                String value2 = txt2.getText();
                String value3 = txt3.getText();
                String value4= txt4.getText();
                String value5 = txt5.getText();
                String value6 = txt6.getText();
                String value7 = txt7.getText();
               
                //  String value11 = txt10.getText();
                
                 
                if((txt1.getText().isEmpty()) && (txt2.getText().isEmpty()) && (txt3.getText().isEmpty()) && (txt4.getText().isEmpty()) && (txt5.getText().isEmpty()) && (txt6.getText().isEmpty()) && (txt7.getText().isEmpty()))
                {
                JOptionPane.showMessageDialog(null, "Fill up all the boxes");
                }
                
                else
                {
                String s= "update Test3 set id='"+value1+"',name='"+value2+"',degree='"+value3+"', "
                + "experties='"+value4+"',mail='"+value5+"',phone='"+value6+"',age='"+value7+"'  where id='"+value1+"' ";
          
                pre=conn.prepareStatement(s);
                 
                pre.executeUpdate();
                JOptionPane.showMessageDialog(null, "Record Updated");
                }
                
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
            finally {

                try{

                    res.close();
                    pre.close();

                }
                catch(Exception e){

                }
            } 
        }
        Table();
    }//GEN-LAST:event_add2ActionPerformed

    private void add3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add3ActionPerformed
        txt1.setText("");
        txt2.setText("");
        txt3.setText("");
        txt4.setText("");
        txt5.setText("");
        txt6.setText("");
        txt7.setText("");
        search.setText("");
    }//GEN-LAST:event_add3ActionPerformed

    private void txt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt6ActionPerformed

    private void txt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt7ActionPerformed

    private void maleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleActionPerformed
       gender = "Male";
       male.setSelected(true);
       female.setSelected(false);
    }//GEN-LAST:event_maleActionPerformed

    private void femaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_femaleActionPerformed
        gender = "Female";
        female.setSelected(true);
        male.setSelected(false);
    }//GEN-LAST:event_femaleActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       conn = Window.ConnectDB();
    }//GEN-LAST:event_formWindowOpened

    private void doc_infoAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_doc_infoAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_doc_infoAncestorMoved

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        MainMenu u = new MainMenu();
        u.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void doc_infoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_doc_infoKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_DOWN || evt.getKeyCode() == KeyEvent.VK_UP)
        {
         try{
       int row =  doc_info.getSelectedRow();
       String table_click = (doc_info.getModel().getValueAt(row, 0).toString());
       String s = "select * from Test3 where id='"+table_click+"' ";
       pre = conn.prepareStatement(s);
       res = pre.executeQuery();
       if(res.next())
       {
       String add1 = res.getString("id");
            txt1.setText(add1);
            
            String add2 =res.getString("name");
            txt2.setText(add2);

            String add3 =res.getString("degree");
            txt3.setText(add3);
            
            String add7 =res.getString("experties");
            txt4.setText(add7);
            
            String add4 =res.getString("mail");
            txt5.setText(add4);

            String add5 =res.getString("phone");
            txt6.setText(add5);

            String add6 =res.getString("age");
            txt7.setText(add6);
       }
       
        }
        
      catch(Exception e)
      {
      
      }  
       try{
       pre.close();
       
       res.close();
       }
       catch(Exception e)
       {
       JOptionPane.showMessageDialog(null, e);
       }
        }
    }//GEN-LAST:event_doc_infoKeyPressed

    private void doc_infoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doc_infoMouseClicked
        try{
       int row =  doc_info.getSelectedRow();
       String table_click = (doc_info.getModel().getValueAt(row, 0).toString());
       String s = "select * from Test3 where id='"+table_click+"' ";
       pre = conn.prepareStatement(s);
       res = pre.executeQuery();
       if(res.next())
       {
       String add1 = res.getString("id");
            txt1.setText(add1);
            
            String add2 =res.getString("name");
            txt2.setText(add2);

            String add3 =res.getString("degree");
            txt3.setText(add3);
            
            String add7 =res.getString("experties");
            txt4.setText(add7);
            
            String add4 =res.getString("mail");
            txt5.setText(add4);

            String add5 =res.getString("phone");
            txt6.setText(add5);

            String add6 =res.getString("age");
            txt7.setText(add6);
       }
       
        }
        
      catch(Exception e)
      {
      JOptionPane.showMessageDialog(null, e);
      }  
       try{
       pre.close();
       
       res.close();
       }
       catch(Exception e)
       {
       
       }
        
    }//GEN-LAST:event_doc_infoMouseClicked

    private void searchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyPressed
        if(evt.getKeyCode()== KeyEvent.VK_END)
       {
        txt1.setText("");
        txt2.setText("");
        txt3.setText("");
        txt4.setText("");
        txt5.setText("");
        txt6.setText("");
        txt7.setText("");
        search.setText("");
       }
    }//GEN-LAST:event_searchKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Information2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Information2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Information2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Information2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Information2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Age;
    private javax.swing.JLabel Age1;
    private javax.swing.JLabel Degree;
    private javax.swing.JLabel Employe_name;
    private javax.swing.JLabel Id;
    private javax.swing.JLabel Mail;
    private javax.swing.JLabel Phone;
    private javax.swing.JLabel Post;
    private javax.swing.JButton add;
    private javax.swing.JButton add1;
    private javax.swing.JButton add2;
    private javax.swing.JButton add3;
    private javax.swing.JTable doc_info;
    private javax.swing.JRadioButton female;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton male;
    private javax.swing.JTextField search;
    private javax.swing.JLabel serchid;
    private javax.swing.JTextField txt1;
    private javax.swing.JTextField txt2;
    private javax.swing.JTextField txt3;
    private javax.swing.JTextField txt4;
    private javax.swing.JTextField txt5;
    private javax.swing.JTextField txt6;
    private javax.swing.JTextField txt7;
    // End of variables declaration//GEN-END:variables
private String gender;
}
